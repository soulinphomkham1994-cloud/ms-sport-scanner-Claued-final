// api/update-status.js
// Vercel Serverless Function
// อัปเดตสถานะใน Google Sheets column F โดยค้นหา Invoice No จาก column E

const { google } = require('googleapis');

// =========================================================
// CONFIG — ตั้งค่าผ่าน Environment Variables ใน Vercel Dashboard
// SPREADSHEET_ID   : ID ของ Google Sheet
// SHEET_NAME       : ชื่อ sheet (2026)
// INV_COLUMN       : คอลัมน์ที่เก็บ Invoice No (E = col 5)
// STATUS_COLUMN    : คอลัมน์ที่เก็บ Status     (F = col 6)
// GOOGLE_CLIENT_EMAIL : Service Account email
// GOOGLE_PRIVATE_KEY  : Service Account private key (ใส่ใน Vercel env โดยไม่ต้อง escape)
// =========================================================

const SPREADSHEET_ID = process.env.SPREADSHEET_ID || '1lPp5LuwT6lAt0wozRduI8ErarHk-5iwI5PWoZwmTZoY';
const SHEET_NAME     = process.env.SHEET_NAME || '2026';
const INV_COLUMN     = parseInt(process.env.INV_COLUMN || '5');    // E = 5
const STATUS_COLUMN  = parseInt(process.env.STATUS_COLUMN || '6'); // F = 6

function getAuth() {
  const privateKey = (process.env.GOOGLE_PRIVATE_KEY || '').replace(/\\n/g, '\n');
  const clientEmail = process.env.GOOGLE_CLIENT_EMAIL || '';

  if (!privateKey || !clientEmail) {
    throw new Error('Missing GOOGLE_CLIENT_EMAIL or GOOGLE_PRIVATE_KEY environment variables');
  }

  return new google.auth.JWT(
    clientEmail,
    null,
    privateKey,
    ['https://www.googleapis.com/auth/spreadsheets']
  );
}

export default async function handler(req, res) {
  // CORS headers — allow any origin (ปรับตามต้องการ)
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ success: false, message: 'Method not allowed' });
  }

  const { inv, status } = req.body || {};

  if (!inv || !status) {
    return res.status(400).json({ success: false, message: 'Missing inv or status' });
  }

  try {
    const auth = getAuth();
    const sheets = google.sheets({ version: 'v4', auth });

    // ดึงข้อมูลทั้งคอลัมน์ E เพื่อค้นหา Invoice No
    const readRange = `${SHEET_NAME}!E:E`;
    const readRes = await sheets.spreadsheets.values.get({
      spreadsheetId: SPREADSHEET_ID,
      range: readRange,
    });

    const rows = readRes.data.values || [];
    let targetRow = -1;

    for (let i = 0; i < rows.length; i++) {
      const cellVal = (rows[i][0] || '').toString().trim().toUpperCase();
      if (cellVal === inv.trim().toUpperCase()) {
        targetRow = i + 1; // Google Sheets rows are 1-indexed
        break;
      }
    }

    if (targetRow === -1) {
      return res.status(404).json({
        success: false,
        message: `ບໍ່ພົບໃບກຳກັບ ${inv} ໃນ Sheet`
      });
    }

    // คอลัมน์ F = ตัวอักษร
    const colLetter = columnToLetter(STATUS_COLUMN);
    const writeRange = `${SHEET_NAME}!${colLetter}${targetRow}`;

    await sheets.spreadsheets.values.update({
      spreadsheetId: SPREADSHEET_ID,
      range: writeRange,
      valueInputOption: 'USER_ENTERED',
      requestBody: { values: [[status]] },
    });

    return res.status(200).json({
      success: true,
      message: `ອັບເດດ ${inv} → ${status} ທີ່ແຖວ ${targetRow} ສຳເລັດ`,
      row: targetRow
    });

  } catch (err) {
    console.error('Sheets API error:', err.message);
    return res.status(500).json({
      success: false,
      message: err.message || 'Internal server error'
    });
  }
}

// แปลงหมายเลขคอลัมน์ → ตัวอักษร (1=A, 6=F, 26=Z, 27=AA ...)
function columnToLetter(col) {
  let letter = '';
  while (col > 0) {
    const rem = (col - 1) % 26;
    letter = String.fromCharCode(65 + rem) + letter;
    col = Math.floor((col - 1) / 26);
  }
  return letter;
}
